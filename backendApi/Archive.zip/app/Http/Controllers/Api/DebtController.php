<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\DebtRequest;
use App\Http\Resources\DebtHistory;
use App\Http\Resources\DebtResource;
use App\Models\BankAccount;
use App\Models\Borrow;
use App\Models\Debt;
use App\Models\DebtCollection;
use App\Models\Lend;
use App\Models\Repayment;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DebtController extends Controller {


	/**
	 * Display a listing of the resource.
	 */

	public function index( Request $request ): JsonResponse {
		$page     = $request->query( 'page', 1 );
		$pageSize = $request->query( 'pageSize', 10 );

		$debts = Debt::where('company_id',Auth::user()->primary_company)
		             ->with(['accounts.bankName'])
		             ->skip( ( $page - 1 ) * $pageSize )
		             ->take( $pageSize )
		             ->orderBy( 'id', 'desc' )
		             ->get();

		$totalCount = Debt::where('company_id',Auth::user()->primary_company)->count();

		return response()->json( [
			'data' => DebtResource::collection( $debts ),
			'total' => $totalCount,
		] );
	}


	/**
	 * @param DebtRequest $request
	 *
	 * @return JsonResponse
	 */
	public function store( DebtRequest $request ): JsonResponse {

		$debt = $request->validated();

        $selectedBankAccount = BankAccount::where('slug',$request->account_id)->first();

        if ( $debt['type'] === 'borrow' ) {
			$debtAmount   = - $debt['amount'];
			$borrowAmount = $debt['amount'];
		} else {
			if ( $debt['amount'] > $selectedBankAccount->balance ) {
				return response()->json( [
					'message'     => 'Insufficient_balance',
					'description' => 'Insufficient balance in the selected bank account. Please use another bank account to repay.',
				] );
			}

			$debtAmount = $debt['amount'];
		}

		$person = $debt['person'];
		$debt = Debt::firstOrCreate( [
			'user_id'    => auth()->user()->id,
			'company_id'    => auth()->user()->primary_company,
			'amount'     => $debtAmount,
			'account_id' => $selectedBankAccount->id,
			'type'       => $debt['type'],
			'person'     => $person,
			'date'       => $debt['date'],
			'note'       => $debt['note']
		] );
		$bankAccount = BankAccount::find( $debt->account_id );

		// Means you are lending money to someone.

		if ( $debt['type'] === 'lend' ) {
			$lendData = Lend::create( [
				'amount'     => $debt->amount,
				'company_id'    => auth()->user()->primary_company,
				'account_id' => $debt->account_id,
				'date'       => $debt['date'],
				'debt_id'    => $debt->id,
				'note'       => $debt['note']
			] );

			// Update Associated bank account by decreasing account balance
			$bankAccount->balance -= $request->amount;
			$bankAccount->save();

			storeActivityLog( [
				'object_id'     => $debt['id'],
				'log_type'     => 'create',
				'module'       => 'Debt',
				'descriptions' => " lend an amount of $debtAmount to $person",
				'data_records' => [
					'lendData'       => $lendData,
					'accountBalance' => $bankAccount->balance
				],
			] );

			return response()->json( [
				'message'     => 'Success!',
				'description' => 'Lend created successfully',
			] );

		}


		// Means you are lending money form someone.

		if ( $debt['type'] === 'borrow' ) {
			$borrowData = Borrow::create( [
				'amount'     => ( $debt->amount * - 1 ),
				'account_id' => $debt->account_id,
				'company_id' => auth()->user()->primary_company,
				'date'       => $debt->date,
				'debt_id'    => $debt->id,
				'note'       => $debt['note']

			] );

			// Update Associated bank account by increasing account balance
			$bankAccount->balance += $request->amount;
			$bankAccount->save();

			storeActivityLog( [
				'user_id'      => Auth::user()->id,
				'object_id'     => $borrowData['id'],
				'log_type'     => 'create',
				'module'       => 'Debt',
				'descriptions' => " has borrowed an amount of $borrowAmount from $person",
				'data_records' => [
					'borrowData'     => $borrowData,
					'accountBalance' => $bankAccount->balance
				],
			] );

			return response()->json( [
				'message'     => 'Success!',
				'description' => 'Borrow created successfully',
			] );

		}


		return response()->json( [
			'message'  => 'Error',
			'description' => 'Something went wrong'
		] );
	}


	/**
	 * @param Debt $debt
	 *
	 * @return DebtResource
	 */

	public function show( Debt $debt ): DebtResource {
		return new DebtResource( $debt );
	}

	/**
	 * @param $debt_id
	 *
	 * @return JsonResponse
	 * @throws ConfigurationException
	 * @throws TwilioException
	 */

	public function getDebtHistory( $debt_id ): JsonResponse {
		$debt = Debt::find( $debt_id );

		if ( $debt->type == 'borrow' ) {
			$borrows          = collect( Borrow::where('company_id',Auth::user()->primary_company)->where( 'debt_id', $debt_id )->get() );
			$repayments       = collect( Repayment::where('company_id',Auth::user()->primary_company)->where( 'debt_id', $debt_id )->get() );
			$borrowRepayments = $borrows->merge( $repayments )->sortByDesc( 'created_at' );

			return response()->json( [
				'infos' => DebtHistory::collection( $borrowRepayments )
			] );
		} else {
			$lends                = collect( Lend::where('company_id',Auth::user()->primary_company)->where( 'debt_id', $debt_id )->get() );
			$debtCollections      = collect( DebtCollection::where('company_id',Auth::user()->primary_company)->where( 'debt_id', $debt_id )->get() );
			$lendsDebtCollections = $lends->merge( $debtCollections )->sortByDesc( 'created_at' );

			return response()->json( [
				'infos' => DebtHistory::collection( $lendsDebtCollections )
			] );
		}

	}

	/**
	 * Update the specified resource in storage.
	 */
	public function update( Request $request, string $id ): JsonResponse {
		$debt = Debt::findOrFail($id);

		// Allow editing basic fields only to avoid balance inconsistencies
		$validated = $request->validate([
			'person' => 'sometimes|string|max:255',
			'date' => 'sometimes|date',
			'note' => 'nullable|string|max:500',
		]);

		$debt->fill($validated);
		$debt->save();

		storeActivityLog([
			'object_id'     => $debt->id,
			'log_type'     => 'update',
			'module'       => 'Debt',
			'descriptions' => 'Debt basic fields updated',
			'data_records' => [
				'id' => $debt->id,
				'updated_fields' => $validated,
			],
		]);

		return response()->json([
			'message'     => 'Success!',
			'description' => 'Debt updated',
		]);
	}


	/**
	 * @param Debt $debt
	 *
	 * @return JsonResponse
	 * @throws Exception
	 */
	public function destroy( $id ): JsonResponse {
		Debt::where( 'id', $id )->delete();
		storeActivityLog( [
			'object_id'     => $id,
			'log_type'     => 'delete',
			'module'       => 'Debt',
			'descriptions' => "",
			'data_records' => [
				'id' => $id,
			],
		] );

		// return response()->json( [
		// 	'message' => 'Debt removed'
		// ] );
		return response()->json( [
			'message'     => 'Success!',
			'description' => 'Debt removed',
		] );
	}
}
