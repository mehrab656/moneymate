<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Api\Interfaces\CategoryRepositoryInterface;
use App\Http\Controllers\Controller;
use App\Http\Requests\CategoryRequest;
use App\Http\Requests\UpdateCategoryRequest;
use App\Http\Resources\BankAccountResource;
use App\Http\Resources\CategoryFilterResource;
use App\Http\Resources\CategoryResource;
use App\Models\Category;
use Illuminate\Support\Facades\DB;
use Exception;
use Hamcrest\Description;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class CategoryController extends Controller {


	private CategoryRepositoryInterface $categoryRepository;

	public function __construct( CategoryRepositoryInterface $categoryRepository ) {
		$this->categoryRepository = $categoryRepository;
	}

    public function index( Request $request ): JsonResponse {
        $page       = $request->query( 'page', 1 );
        $pageSize   = $request->query( 'pageSize', 10 );
        $sectorID   = $request->query( 'selectedSectorId', null );
        $type       = $request->query( 'categoryType', null );

        // Use Eloquent to return Category models instead of stdClass
        $query = Category::query()
            ->with('sector')
            ->select('categories.*')
            ->join('sectors', 'categories.sector_id', '=', 'sectors.id')
            ->where('sectors.company_id', '=', Auth::user()->primary_company);

        if ($sectorID) {
            $query->where('sectors.id', '=', $sectorID);
        }
        if ($type) {
            $query->where('type', '=', $type);
        }

        $categories = $query->skip( ( $page - 1 ) * $pageSize )->take( $pageSize )->get();

        return response()->json([
            'data'  => CategoryResource::collection($categories),
            'total' => Category::count(),
            'currentPage'=> (int) $page
        ]);
    }

	/**
	 * @throws Exception
	 */
    public function create( CategoryRequest $request ): JsonResponse {
        $categoryData               = $request->validated();
        $categoryData['user_id']    = auth()->user()->id;

        // Resolve sector identifier to numeric sector ID if a slug/UUID is provided
        if (array_key_exists('sector_id', $categoryData)) {
            $sectorIdentifier = $categoryData['sector_id'];
            if (!is_numeric($sectorIdentifier)) {
                $sector = \App\Models\SectorModel::where('slug', $sectorIdentifier)->first();
                if (!$sector) {
                    return response()->json([
                        'message' => 'Not Found',
                        'description' => 'Sector could not be found for the given identifier.'
                    ], 400);
                }
                $categoryData['sector_id'] = $sector->id;
            } else {
                // Ensure we only use an existing sector ID
                $sector = \App\Models\SectorModel::find((int) $sectorIdentifier);
                if (!$sector) {
                    return response()->json([
                        'message' => 'Not Found',
                        'description' => 'Sector could not be found for the given identifier.'
                    ], 400);
                }
            }
        }

        // Generate a UUID slug and persist it
        $categoryData['slug'] = (string) Str::uuid();

        $category = $this->categoryRepository->create( $categoryData );
        storeActivityLog( [
            'object_id'    => $category->id,
            'log_type'     => 'create',
			'module'       => 'Category',
			'descriptions' => "",
			'data_records' => $category,
		] );

		// return response()->json( [ 'category' => $category ] );

		return response()->json( [
			'message'     => 'Success!',
			'description' => 'Category successfully created!.',
		] );
	}

	public function show( Category $category ): CategoryResource {
		return new CategoryResource( $category );
	}

	/**
	 * @throws Exception
	 */
    public function update( UpdateCategoryRequest $request, Category $category ): JsonResponse {
        $data     = $request->validated();

        // If sector_id is provided (may be a slug from UI), resolve to numeric ID
        if (array_key_exists('sector_id', $data) && !empty($data['sector_id'])) {
            $sectorIdentifier = $data['sector_id'];
            if (!is_numeric($sectorIdentifier)) {
                $sector = \App\Models\SectorModel::where('slug', $sectorIdentifier)->first();
                if (!$sector) {
                    return response()->json([
                        'message' => 'Not Found',
                        'description' => 'Sector could not be found for the given identifier.'
                    ], 400);
                }
                $data['sector_id'] = $sector->id;
            } else {
                $sector = \App\Models\SectorModel::find((int) $sectorIdentifier);
                if (!$sector) {
                    return response()->json([
                        'message' => 'Not Found',
                        'description' => 'Sector could not be found for the given identifier.'
                    ], 400);
                }
            }
        }
		$oldData  = $category;
        $category = $this->categoryRepository->update( $category, $data );

		storeActivityLog( [
			'object_id'    => $category->id,
			'log_type'     => 'edit',
			'module'       => 'Category',
			'descriptions' => "",
			'data_records' => [
				'Old Data' => $oldData,
				'New Data' => $category
			],
		] );

		// return new CategoryResource( $category );
		return response()->json( [
			'message'     => 'Success!',
			'description' => 'Category successfully updated!.',
		] );
	}


	/**
	 * Remove the specified resource from storage.
	 *
	 * @param Category $category
	 *
	 * @return JsonResponse
	 * @throws Exception
	 */
	public function destroy( Category $category ): JsonResponse {
		$this->categoryRepository->delete( $category );
		storeActivityLog( [
			'object_id'    => $category->id,
			'log_type'     => 'delete',
			'module'       => 'Category',
			'descriptions' => "",
			'data_records' => [
				'Old Record' => $category,
			],
		] );

		// return response()->json( [ 'message' => 'Category deleted' ] );
		return response()->json( [
			'message'     => 'Success!',
			'description' => 'Category successfully deleted!.',
		] );
	}

    /**
     * Get the list of this company categories based on types.
     * @param Request $request
     * @return JsonResponse
     */
    public function categories(Request $request): JsonResponse
    {
        $type = $request->type;
        $query = Category::query()
            ->select('categories.*')
            ->join('sectors', 'categories.sector_id', '=', 'sectors.id')
            ->where('sectors.company_id', '=', Auth::user()->primary_company);

        if ($type) {
            $query->where('type', $type);
        }

        return response()->json([
            'data' => CategoryFilterResource::collection($query->get()),
        ]);
    }

}
